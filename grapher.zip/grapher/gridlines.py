from __future__ import division
import turtle
g = turtle.Turtle()
g.ht()
def l(le):
    g.forward(le)
    g.backward(le)
def graph(w):
    g.goto(0, 0)
    g.speed('fastest')
    def grid(d):
        for i in range(-w, w + 1):
            g.up()
            if i * (200 / w) == 0:
                g.pensize(4)
            else:
                g.pensize(1)
            if d == 'v':
                g.goto(i * (200 / w), -200)
                g.down()
                l(400)
            elif d == 'h':
                g.goto(-200, i * (200 / w))
                g.down()
                l(400)
    grid('h')
    g.left(90)
    grid('v')
    g.right(90)
