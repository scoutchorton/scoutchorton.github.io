from __future__ import division
import turtle
from calcs import *
l = turtle.Turtle()
l.ht()
def draw(w, equ):
    u = 1 / (200 / w)
    p = 200 / w
    l.up()
    l.speed('slow')
    l.pensize(2)
    l.color('red')
    for x in dran(-w, w, u):
        y = equ
        y = y.split('x')
        y = ('*(' + str(x) + ')').join(y)
        y = eval(y)
        l.goto(x * p, y * p)
        if y >= -p / 2 and y <= p / 2:
            l.down()
        else:
            l.up()
